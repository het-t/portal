"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var logout = function logout(req, res) {
  res.send('ok');
};
var _default = logout;
exports["default"] = _default;