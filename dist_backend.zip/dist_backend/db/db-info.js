"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var dbInfo = {
  "host": "localhost",
  "user": "root",
  "password": "het161967",
  "database": "portal",
  "multipleStatements": true
};
var _default = dbInfo;
exports["default"] = _default;